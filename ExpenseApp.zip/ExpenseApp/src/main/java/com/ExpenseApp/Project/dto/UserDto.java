package com.ExpenseApp.Project.dto;

public class UserDto
{
	private Integer id;
	private String email;
	private String password;

}
