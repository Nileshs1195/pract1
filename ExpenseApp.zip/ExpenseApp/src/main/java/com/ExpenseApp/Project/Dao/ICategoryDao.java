package com.ExpenseApp.Project.Dao;

import java.util.List;
import java.util.Optional;

import com.ExpenseApp.Project.pojo.Category;

public interface ICategoryDao
{		
	//public Category getCategoryById(int cid);
}



